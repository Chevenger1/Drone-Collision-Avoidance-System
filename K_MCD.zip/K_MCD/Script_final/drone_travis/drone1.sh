#!/bin/bash
sim_vehicle.py -v ArduCopter -f gazebo-iris --console -l 30.4897,-98.13564,0,0

